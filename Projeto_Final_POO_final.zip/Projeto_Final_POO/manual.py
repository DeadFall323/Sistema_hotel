import time
from main import aguarde_com_pontos

def mostrar_manual():
    print("╔════════════════════════════════════════╗")
    print("║            🌟 Forza Hotel 🌟           ║")
    print("╠════════════════════════════════════════╣")
    print("║  Selecione uma opção:                  ║")
    print("║                                        ║")
    print("║  1 - Cadastrar novo hóspede            ║")
    print("║  2 - Dar baixa em um hóspede           ║")
    print("║  3 - Mostrar clientes cadastrados      ║")
    print("║  4 - Atribuir vaga de garagem a um     ║")
    print("║      cliente                           ║")
    print("║  5 - Remover vaga de garagem de um     ║")
    print("║      cliente                           ║")
    print("║  6 - [DEV] Criar cliente de teste      ║")
    print("║  7 - Buscar cadastro do cliente        ║")
    print("║  8 - Mostrar vagas de garagem          ║")
    print("║  9 - Mostrar quartos disponíveis       ║")
    print("║ 10 - Sobre                             ║")
    print("║ 11 - Mostrar histórico                 ║")
    print("║  0 - Sair                              ║")
    print("║                                        ║")
    print("╚════════════════════════════════════════╝")
    opcao = input("\nDigite o número da opção desejada:")
    if opcao == '1':
        print(print("║  1 - Cadastrar novo hóspede            ║"))
        time.sleep(1)
        print("Nessa opção o sistema vai receber por meio do teclado os dados do cliente no seguinte formato:")
        print("Nome: (Insira o nome) ")
        print("Idade: (Insira a idade)")
        print("O cliente deve ter idade maior que 18 anos, caso o contrário, não será possivel fazer o cadastro!!!")
        print("CPF: (Insira o CPF)")
        print("O CPF deve ser um CPF valido (Formato Brasileiro), o sistema não aceitará um CPF inválido!!!")
        print("Numero: (Insira o numero de telefone)")
        print("")
        aguarde_com_pontos()
    elif opcao == '2':
        print("║  2 - Dar baixa em um hóspede           ║")
        time.sleep(1)
        print("Nessa opção o sistema solicitará o CPF, e o cliente associsado ao CPF será removido do sistema")
        print("CPF do cliente para dar baixa: (Insira o CPF a ser removido) ")
        print(
            "nesse ponto o sistema irá verificar se o cliente do CPF associado está cadastrado atualmente no hotel, caso essa verificação"
            "seja verdade, o sistema fará mais uma verificação se esse cliente possui uma vaga de garagem atribuida ao seu quarto")
        print("Caso a primeira verificação seja concluida, retornará a seguinte mensagem: ")
        print(
            f"Cliente (cliente_nome) deixou o hotel!\nQuarto utilizado: (quarto_utilizado)\nNúmero da Vaga na Garagem: (vaga_garagem)")
        aguarde_com_pontos()
    elif opcao == '3':
        print("║  3 - Mostrar clientes cadastrados      ║")
        print("Nessa opção o sistema irá mostrar os clientes cadastrados no hotel no seguinte formato:")
        print(f"Cliente: (cliente.nome_pessoa)\nQuarto: (quarto)\nVaga de Garagem: (garagem)\n")
        print("Mostrará toda a lista de clientes")
        aguarde_com_pontos()
    elif opcao == '4':
        print("║  4 - Atribuir vaga de garagem a um     ║")
        print("║      cliente                           ║")
        print("Nessa opção o sistema irá solicitar um CPF ")
        print(
            "Logo após isso o sistema fará uma verificação se o CPF possui cadastro no hotel, e verificará a vaga de garagem (se o Cliente possuir)")
        print(
            "Caso o cliente possua vaga o sistema retorna a mensagem que o cliente já possui vaga, dessa forma não atribuindo uma segunda")
        print("Caso o cliente não possua vaga, o sistema irá atribuir alguma vaga disponivel no sistema")
        aguarde_com_pontos()
    elif opcao == '5':
        print("║  5 - Remover vaga de garagem de um     ║")
        print("║      cliente                           ║")
        print("Nessa opção o sistema irá solicitar um CPF ")
        print(
            "Logo após isso o sistema fará uma verificação se o CPF possui cadastro no hotel, e verificará a vaga de garagem (se o Cliente possuir)")
        print(
            "Caso o cliente possua vaga o sistema irá atribuir uma vaga(Caso alguma estaja disponivel")
        print(
            "Caso o cliente não possua vaga, o sistema irá retornar um aviso que não é possivel remover a vaga, já que o mesmo não possui uma!!!")
        aguarde_com_pontos()
    elif opcao == '6':
        print("║  6 - [DEV] Criar cliente de teste      ║")
        print("ESSA OPÇÃO É APENAS PARA TESTE DO SISTEMA ")
        print(
            "Nessa opção o sistema fará irá gerar nome, idade, cpf(Valido),numero todos aleatórios. O sistema requisitará que o quarto disponivel seja atribuido de forma manual e"
            "perguntará se o usuário deseja uma vaga")
        print("APENAS PARA FACILITAR OS TESTES DO SISTEMA")
        print("ESSA OPÇÃO SERÁ REMOVIDA DA VERSÃO FINAL")
        aguarde_com_pontos()

    elif opcao == '7':
        print("║  7 - Buscar cadastro do cliente        ║")
        print(
            "Essa opção é feita para auxiliar o operador do sistema, caso ele não saiba o CPF do cliente, basta inserir o nome cadastrado(nome esse que pode ser visualizado"
            "na aba mostrar clientes")
        print("Logo após inserir o nome, o sistema retornará todos os dados do cliente no seguinte formato:")
        print("Dados do cliente:")
        print(f"Nome: (cliente.nome_pessoa)")
        print(f"CPF: (cliente.cpf_pessoa)")
        print(f"Idade: (cliente.idade_pessoa)")
        print(f"Número do Quarto: (cliente.numero_quarto)")
        print(
            f"Número da Vaga de Garagem: (cliente.numero_vaga_garagem if cliente.numero_vaga_garagem else 'Não atribuída')")
        print(
            "    Nessa linha a cima será impressa a o quarto do usuário, caso a vaga de garagem tenha um valor diferente de None, seŕa impresso a vaga de garagem atribuida")
        aguarde_com_pontos()

    elif opcao == '8':
        print("║  8 - Mostrar vagas de garagem          ║")
        print("Nessa opção o sistema irá mostrar as vagas de garagem cadastrada no sistema:")
        print(f"Vaga (vaga): Disponível")
        print(f"Vaga (vaga): (Quarto atribuido")
        aguarde_com_pontos()

    elif opcao == '9':
        print("║  9 - Mostrar quartos disponíveis       ║")
        print("Nessa opção o sistema irá retornar os quartos disponiveis no hotel, mostrando a divisão por andares")
        print("10* Quartos:")
        print("Andar: 6")
        print("10* Quartos:")
        print("Andar: 5")
        print("10* Quartos:")
        print("Andar: 4")
        print("10* Quartos:")
        print("Andar: 3")
        print("10* Quartos:")
        print("Andar: 2")
        print("10* Quartos:")
        print("Andar: 1 ")
        aguarde_com_pontos()

    elif opcao == '10':
        print("Mostra as informações do software, prédio, e contato")
        aguarde_com_pontos()

    elif opcao == '11':
        print("Nessa opção o sistema irá mostrar o historico de cadastros do sistema, ")
        print("Mostra a data de entrada ")
        print("Mostra a data de saida")
        aguarde_com_pontos()

    elif opcao == '12':
        print("Mostra o manual do sistema")
        aguarde_com_pontos()

